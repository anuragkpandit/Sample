package com.springBootRedisProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRedisProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
